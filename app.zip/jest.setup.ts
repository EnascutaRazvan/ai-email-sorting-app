process.env.NEXT_PUBLIC_SUPABASE_URL = 'http://fake.supabase.io';
process.env.SUPABASE_SERVICE_ROLE_KEY = 'fake-key';
