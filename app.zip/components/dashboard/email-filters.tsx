// email-filters.tsx
"use client"

import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Filter, SortAsc, SortDesc, Search } from "lucide-react"

interface Category { id: string; name: string; color: string; email_count: number }
interface Account { id: string; email: string; name?: string }

interface EmailFiltersProps {
  searchQuery: string
  onSearchChange: (q: string) => void
  selectedCategory: string | null
  onCategoryChange: (c: string | null) => void
  sortBy: string
  onSortChange: (s: string) => void
  sortOrder: "asc" | "desc"
  onSortOrderChange: (o: "asc" | "desc") => void
  dateRange: string
  onDateRangeChange: (r: string) => void
  accounts: Account[]
  selectedAccount: string | null
  onAccountChange: (a: string | null) => void
  totalEmails: number
  filteredEmails: number
}

export function EmailFilters({
  searchQuery,
  onSearchChange,
  selectedCategory,
  onCategoryChange,
  sortBy,
  onSortChange,
  sortOrder,
  onSortOrderChange,
  dateRange,
  onDateRangeChange,
  accounts,
  selectedAccount,
  onAccountChange,
  totalEmails,
  filteredEmails,
}: EmailFiltersProps) {
  return (
    <div className="flex flex-col lg:flex-row items-center justify-between p-4 bg-card rounded-lg border">
      <div className="flex flex-wrap items-center space-x-4 mb-2 lg:mb-0">
        <div className="flex items-center space-x-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium">Filters</span>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search emails"
            value={searchQuery}
            onChange={e => onSearchChange(e.target.value)}
            className="pl-8 w-64"
          />
        </div>

        {/* Category */}
        <Select
          value={selectedCategory ?? "all"}
          onValueChange={v => onCategoryChange(v === "all" ? null : v)}
        >
          <SelectTrigger className="w-40">
            <SelectValue placeholder="All categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All categories</SelectItem>
            <SelectItem value="uncategorized">Uncategorized</SelectItem>
            <SelectItem value="unread">Unread</SelectItem>
            <SelectItem value="starred">Starred</SelectItem>
            <SelectItem value="archived">Archived</SelectItem>
          </SelectContent>
        </Select>

        {/* Sort by */}
        <Select value={sortBy} onValueChange={onSortChange}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="date">Date</SelectItem>
            <SelectItem value="sender">Sender</SelectItem>
            <SelectItem value="subject">Subject</SelectItem>
          </SelectContent>
        </Select>

        <Button
          variant="outline"
          size="sm"
          onClick={() => onSortOrderChange(sortOrder === "asc" ? "desc" : "asc")}
        >
          {sortOrder === "asc" ? <SortAsc className="h-4 w-4" /> : <SortDesc className="h-4 w-4" />}
        </Button>

        {/* Date range */}
        <Select value={dateRange} onValueChange={onDateRangeChange}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="Date range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All time</SelectItem>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="week">This week</SelectItem>
            <SelectItem value="month">This month</SelectItem>
          </SelectContent>
        </Select>

        {/* Account filter */}
        {accounts.length > 1 && (
          <Select
            value={selectedAccount ?? "all"}
            onValueChange={v => onAccountChange(v === "all" ? null : v)}
          >
            <SelectTrigger className="w-40">
              <SelectValue placeholder="All accounts" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All accounts</SelectItem>
              {accounts.map(a => (
                <SelectItem key={a.id} value={a.id}>{a.email}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      <Badge variant="outline">
        {filteredEmails} of {totalEmails} emails
      </Badge>
    </div>
  )
}
