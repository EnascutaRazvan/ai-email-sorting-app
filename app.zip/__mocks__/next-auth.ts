// __mocks__/next-auth.ts
export const getServerSession = jest.fn()
export default jest.fn(() => ({}))
